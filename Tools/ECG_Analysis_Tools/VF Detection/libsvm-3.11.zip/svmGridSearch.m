function [tr_metric,t_metric tr_se tr_sp t_se t_sp] = ...
    svmGridSearch(tr_data, tr_target, t_data, t_target, gammaSS,capacitySS, input_options)
%SVMGRIDSEARCH Performs a grid search to determine the best gamma and
%capacity hyperparameters on the given training set.
%
%[tr_metric,t_metric] = ...
%    svmGridSearch(tr_data, tr_target, t_data, t_target, gammaSS,capacitySS, input_options)
%
%	Inputs:
%       tr_data     - Data used for training SVM
%       tr_target   - Training targets for SVM (0/1s)
%       t_data      - Data used for testing SVM
%       t_target    - Test targets for SVM (0/1s)
%       gammaSS     - Double vector of gamma values to be evaluated
%       capacitySS  - Double vector of capacity values to be evaluated
%
%	Outputs:
%		tr_metric   - Matrix of performances on the training set using
%           various hyperparameters
%		t_metric   - Matrix of performances on the test set using
%           various hyperparameters
%
%	Example:
%       gammaSS=2.^(-15:2:3);
%       capacitySS=2.^(-5:2:15);
%       
%		[tr_metric,t_metric] = ...
%           svmGridSearch(tr_data, tr_target, t_data, t_target, ...
%           gammaSS,capacitySS, '-w0 1 -w1 1 -b 1')
%	
%	See also LIBSVMGRIDSEARCHMAIN

%	Copyright 2012 Alistair Johnson

%   $LastChangedBy: alistair $
%   $LastChangedDate: 2012-01-24 15:20:35 +0000 (Tue, 24 Jan 2012) $
%   $Revision: 119 $
%   Originally written on GLNXA64 by Alistair Johnson
%   Contact:alistairewj@gmail.com

metric_str='Noooooooooooooooooooooooooooooooo_AUROC';
if nargin<7
    input_options='-b 1';
else
    % Parse input_options - ensure -b 1 is included
    b0=regexp(input_options,'-b 0', 'once');
    b1=regexp(input_options,'-b 1', 'once');
    if isempty(b1)
        if isempty(b0)
            input_options=[input_options ' -b 1'];
        else
            input_options(b0:b0+3)='-b 1';
        end
    end
end

gL=length(gammaSS);
cL=length(capacitySS);
tr_metric=zeros(gL, cL);
t_metric=zeros(gL, cL);

% Train model using LIBSVM
for n=1:gL
    for m=1:cL
        svm_options=[input_options ' -c ' num2str(capacitySS(m)) ' -g ' num2str(gammaSS(n)) ];
        svm = svmtrain(tr_target, tr_data, svm_options);
        [tr_pred, tr_acc, tr_prob] = svmpredict(tr_target, tr_data, svm, '-b 1');
        [t_pred, t_acc, t_prob] = svmpredict(t_target, t_data, svm, '-b 1');
        
        if strcmp(metric_str,'AUROC')
            tr_metric(n,m)=cstat(tr_prob(:,1),tr_target);
            t_metric(n,m)=cstat(t_prob(:,1),t_target);
        else
            tr_metric(n,m)=tr_acc(1)/100; % normalize accuracy to 0-1
            t_metric(n,m)=t_acc(1)/100; % normalize accuracy to 0-1
        end
        
        y = tr_pred - tr_target;
        TP=length(find(y==0 & tr_target==1));
        FN=length(find(y==-1));
        TN=length(find(y==0 & tr_target==0));
        FP=length(find(y==1));
        tr_se(n,m)=TP/(TP+FN);
        tr_sp(n,m)=TN/(FP+TN);
        
        y = t_pred - t_target;
        TP=length(find(y==0 & t_target==1));
        FN=length(find(y==-1));
        TN=length(find(y==0 & t_target==0));
        FP=length(find(y==1));
        t_se(n,m)=TP/(TP+FN);
        t_sp(n,m)=TN/(FP+TN);

    end
end

end
